#!/usr/bin/env python3
"""Dependency-free client for reproducible medRxiv metadata searches."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import shlex
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable


VERSION = "1.0.0"
API_ENDPOINT = "https://api.biorxiv.org/details/medrxiv"
USER_AGENT = os.environ.get(
    "MEDRXIV_USER_AGENT",
    "arxiv-medrxiv-search-skill/1.0 (+https://api.biorxiv.org/)",
)
MIN_REQUEST_INTERVAL_SECONDS = 0.5
CACHE_TTL_SECONDS = 12 * 60 * 60
DEFAULT_LOOKBACK_DAYS = 30
DEFAULT_MAX_SOURCE_RECORDS = 5000
ABSOLUTE_MAX_SOURCE_RECORDS = 30000
MAX_RETURNED_RESULTS = 2000
RETRYABLE_HTTP_CODES = {429, 500, 502, 503, 504}


class MedrxivError(RuntimeError):
    """Base error shown cleanly by the CLI."""


class MedrxivResponseError(MedrxivError):
    """Error encoded in or inferred from an API response."""


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso_utc(value: datetime | None = None) -> str:
    value = value or _utc_now()
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _normalize_space(value: Any) -> str | None:
    if value is None:
        return None
    normalized = " ".join(str(value).split())
    return normalized or None


def _optional_text(value: Any) -> str | None:
    normalized = _normalize_space(value)
    if normalized is None or normalized.casefold() in {"na", "n/a", "none"}:
        return None
    return normalized


def _integer(value: Any, label: str, default: int = 0) -> int:
    if value in (None, ""):
        return default
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise MedrxivResponseError(f"Invalid integer for {label}: {value!r}") from exc


def parse_api_payload(payload: bytes) -> dict[str, Any]:
    try:
        decoded = json.loads(payload.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        preview = payload[:240].decode("utf-8", errors="replace")
        raise MedrxivResponseError(
            f"medRxiv returned invalid JSON: {preview}"
        ) from exc

    if not isinstance(decoded, dict):
        raise MedrxivResponseError("medRxiv response must be a JSON object")
    messages = decoded.get("messages")
    collection = decoded.get("collection")
    if not isinstance(messages, list) or not messages or not isinstance(messages[0], dict):
        raise MedrxivResponseError("medRxiv response is missing a messages object")
    if not isinstance(collection, list) or not all(
        isinstance(item, dict) for item in collection
    ):
        raise MedrxivResponseError("medRxiv response has an invalid collection")

    message = messages[0]
    status = _normalize_space(message.get("status")) or ""
    if status.casefold() != "ok":
        raise MedrxivResponseError(status or "medRxiv returned an unspecified error")
    return {"message": message, "collection": collection}


@dataclass(frozen=True)
class ApiResult:
    parsed: dict[str, Any]
    request_url: str
    cache_hit: bool
    source_fetched_at_utc: str


@dataclass(frozen=True)
class ScanResult:
    records: list[dict[str, Any]]
    source_total_version_records: int
    source_new_papers: int | None
    api_pages: int
    cache_hits: int
    source_fetched_from_utc: str | None
    source_fetched_through_utc: str | None


class MedrxivClient:
    def __init__(
        self,
        *,
        api_endpoint: str = API_ENDPOINT,
        timeout: float = 45.0,
        max_retries: int = 3,
        cache_ttl: float = CACHE_TTL_SECONDS,
        cache_dir: Path | None = None,
        rate_state: Path | None = None,
    ) -> None:
        self.api_endpoint = api_endpoint.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.cache_ttl = cache_ttl
        temp_root = Path(tempfile.gettempdir())
        self.cache_dir = cache_dir or temp_root / "medrxiv-search-cache"
        self.rate_state = rate_state or temp_root / "medrxiv-search-rate-limit"

    def interval_page(
        self,
        posted_from: str,
        posted_to: str,
        cursor: int,
        *,
        category: str | None = None,
        refresh: bool = False,
    ) -> ApiResult:
        path = f"{self.api_endpoint}/{posted_from}/{posted_to}/{cursor}/json"
        if category:
            path = f"{path}?{urllib.parse.urlencode({'category': category})}"
        return self._get(path, refresh=refresh)

    def doi(self, doi: str, *, refresh: bool = False) -> ApiResult:
        encoded = urllib.parse.quote(doi, safe="/._-")
        return self._get(f"{self.api_endpoint}/{encoded}/na/json", refresh=refresh)

    def _get(self, request_url: str, *, refresh: bool) -> ApiResult:
        cache_path = self._cache_path(request_url)
        if not refresh:
            cached = self._read_cache(cache_path)
            if cached is not None:
                payload, fetched_at = cached
                try:
                    return ApiResult(
                        parse_api_payload(payload), request_url, True, fetched_at
                    )
                except MedrxivResponseError:
                    try:
                        cache_path.unlink()
                    except OSError:
                        pass

        payload = self._request_with_retries(request_url)
        fetched_at = _iso_utc()
        parsed = parse_api_payload(payload)
        self._write_cache(cache_path, payload)
        return ApiResult(parsed, request_url, False, fetched_at)

    def _cache_path(self, request_url: str) -> Path:
        digest = hashlib.sha256(request_url.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{digest}.json"

    def _read_cache(self, path: Path) -> tuple[bytes, str] | None:
        try:
            stat = path.stat()
            if time.time() - stat.st_mtime > self.cache_ttl:
                return None
            return (
                path.read_bytes(),
                _iso_utc(datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)),
            )
        except (FileNotFoundError, OSError):
            return None

    def _write_cache(self, path: Path, payload: bytes) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            handle, temp_name = tempfile.mkstemp(prefix=".medrxiv-", dir=path.parent)
            try:
                with os.fdopen(handle, "wb") as stream:
                    stream.write(payload)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temp_name, path)
            finally:
                try:
                    os.unlink(temp_name)
                except FileNotFoundError:
                    pass
        except OSError:
            return

    def _request_with_retries(self, request_url: str) -> bytes:
        last_error: BaseException | None = None
        for attempt in range(self.max_retries + 1):
            try:
                return self._throttled_get(request_url)
            except urllib.error.HTTPError as exc:
                last_error = exc
                body = exc.read(65536)
                detail = body[:500].decode("utf-8", errors="replace")
                if exc.code not in RETRYABLE_HTTP_CODES or attempt >= self.max_retries:
                    raise MedrxivError(
                        f"medRxiv HTTP {exc.code}: {detail or exc.reason}"
                    ) from exc
                delay = self._retry_delay(attempt, exc.headers.get("Retry-After"))
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    raise MedrxivError(f"Unable to reach medRxiv API: {exc}") from exc
                delay = max(MIN_REQUEST_INTERVAL_SECONDS, 2**attempt)
            time.sleep(delay)
        raise MedrxivError(f"Unable to reach medRxiv API: {last_error}")

    @staticmethod
    def _retry_delay(attempt: int, retry_after: str | None) -> float:
        if retry_after:
            try:
                return min(60.0, max(MIN_REQUEST_INTERVAL_SECONDS, float(retry_after)))
            except ValueError:
                pass
        return min(60.0, max(MIN_REQUEST_INTERVAL_SECONDS, 2**attempt))

    def _throttled_get(self, request_url: str) -> bytes:
        self.rate_state.parent.mkdir(parents=True, exist_ok=True)
        with self.rate_state.open("a+", encoding="utf-8") as state:
            fcntl.flock(state.fileno(), fcntl.LOCK_EX)
            try:
                state.seek(0)
                raw = state.read().strip()
                try:
                    last_finished = float(raw) if raw else 0.0
                except ValueError:
                    last_finished = 0.0
                wait_for = MIN_REQUEST_INTERVAL_SECONDS - (time.time() - last_finished)
                if wait_for > 0:
                    time.sleep(wait_for)

                request = urllib.request.Request(
                    request_url,
                    headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
                    method="GET",
                )
                try:
                    with urllib.request.urlopen(request, timeout=self.timeout) as response:
                        return response.read()
                finally:
                    state.seek(0)
                    state.truncate()
                    state.write(str(time.time()))
                    state.flush()
                    os.fsync(state.fileno())
            finally:
                fcntl.flock(state.fileno(), fcntl.LOCK_UN)


def _parse_date(value: str, label: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise MedrxivError(f"{label} must be YYYY-MM-DD: {value}") from exc


def _resolve_interval(args: argparse.Namespace) -> tuple[str, str]:
    if args.days is not None and (args.posted_from or args.posted_to):
        raise MedrxivError("--days cannot be combined with --posted-from/--posted-to")
    today = _utc_now().date()
    if args.days is not None:
        if args.days < 1:
            raise MedrxivError("--days must be >= 1")
        posted_to = today
        posted_from = today - timedelta(days=args.days - 1)
    else:
        posted_to = (
            _parse_date(args.posted_to, "--posted-to") if args.posted_to else today
        )
        posted_from = (
            _parse_date(args.posted_from, "--posted-from")
            if args.posted_from
            else posted_to - timedelta(days=DEFAULT_LOOKBACK_DAYS - 1)
        )
    if posted_from > posted_to:
        raise MedrxivError("--posted-from must not be after --posted-to")
    if posted_to > today:
        raise MedrxivError("--posted-to must not be in the future (UTC)")
    return posted_from.isoformat(), posted_to.isoformat()


def _split_authors(value: Any) -> list[str]:
    normalized = _normalize_space(value)
    if not normalized:
        return []
    return [part.strip() for part in normalized.split(";") if part.strip()]


def _record_from_api(raw: dict[str, Any]) -> dict[str, Any]:
    doi = _normalize_space(raw.get("doi"))
    if not doi:
        raise MedrxivResponseError("A medRxiv record is missing its DOI")
    version_text = _normalize_space(raw.get("version"))
    try:
        version: int | None = int(version_text) if version_text else None
    except ValueError as exc:
        raise MedrxivResponseError(
            f"Invalid version for medRxiv DOI {doi}: {version_text!r}"
        ) from exc
    versioned_id = f"{doi}v{version}" if version is not None else doi
    return {
        "source": "medRxiv",
        "doi": doi,
        "version": version,
        "versioned_id": versioned_id,
        "title": _normalize_space(raw.get("title")),
        "authors": _split_authors(raw.get("authors")),
        "author_corresponding": _optional_text(raw.get("author_corresponding")),
        "author_corresponding_institution": _optional_text(
            raw.get("author_corresponding_institution")
        ),
        "abstract": _normalize_space(raw.get("abstract")),
        "posted": _normalize_space(raw.get("date")),
        "category": _normalize_space(raw.get("category")),
        "type": _normalize_space(raw.get("type")),
        "license": _optional_text(raw.get("license")),
        "published_doi": _optional_text(raw.get("published")),
        "server": _normalize_space(raw.get("server")),
        "funder": raw.get("funder", raw.get("funding")),
        "jats_xml_url": _optional_text(raw.get("jatsxml")),
        "doi_url": f"https://doi.org/{doi}",
        "abstract_url": f"https://www.medrxiv.org/content/{versioned_id}",
        "pdf_url": f"https://www.medrxiv.org/content/{versioned_id}.full.pdf",
    }


def _collect_interval(
    client: MedrxivClient,
    posted_from: str,
    posted_to: str,
    *,
    category: str | None,
    max_source_records: int,
    refresh: bool,
) -> ScanResult:
    if not 1 <= max_source_records <= ABSOLUTE_MAX_SOURCE_RECORDS:
        raise MedrxivError(
            f"--max-source-records must be between 1 and {ABSOLUTE_MAX_SOURCE_RECORDS}"
        )

    cursor = 0
    source_total: int | None = None
    source_new_papers: int | None = None
    records: list[dict[str, Any]] = []
    seen: set[tuple[str, int | None, str | None]] = set()
    pages = 0
    cache_hits = 0
    fetched_times: list[str] = []

    while source_total is None or cursor < source_total:
        result = client.interval_page(
            posted_from,
            posted_to,
            cursor,
            category=category,
            refresh=refresh,
        )
        pages += 1
        cache_hits += int(result.cache_hit)
        fetched_times.append(result.source_fetched_at_utc)
        message = result.parsed["message"]
        page = result.parsed["collection"]

        reported_total = _integer(message.get("total"), "total", len(page))
        if source_total is None:
            source_total = reported_total
            raw_new = message.get("count_new_papers")
            source_new_papers = (
                _integer(raw_new, "count_new_papers") if raw_new not in (None, "") else None
            )
            if source_total > max_source_records:
                raise MedrxivError(
                    f"The API interval contains {source_total} version records, exceeding "
                    f"--max-source-records={max_source_records}; narrow the dates/category "
                    "or raise the limit explicitly"
                )
        else:
            source_total = max(source_total, reported_total)
            if source_total > max_source_records:
                raise MedrxivError(
                    "The result set grew beyond --max-source-records during paging; "
                    "narrow the dates/category and retry"
                )

        if not page and cursor < source_total:
            raise MedrxivResponseError(
                "medRxiv returned an empty page before the reported total"
            )

        for raw_record in page:
            record = _record_from_api(raw_record)
            key = (record["doi"], record["version"], record["posted"])
            if key not in seen:
                seen.add(key)
                records.append(record)

        page_count = _integer(message.get("count"), "count", len(page))
        advance = max(page_count, len(page))
        if advance <= 0:
            if cursor < (source_total or 0):
                raise MedrxivResponseError(
                    "medRxiv pagination stopped before the reported total"
                )
            break
        cursor += advance

    return ScanResult(
        records=records,
        source_total_version_records=source_total or 0,
        source_new_papers=source_new_papers,
        api_pages=pages,
        cache_hits=cache_hits,
        source_fetched_from_utc=min(fetched_times) if fetched_times else None,
        source_fetched_through_utc=max(fetched_times) if fetched_times else None,
    )


def _latest_returned_per_doi(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for record in records:
        current = latest.get(record["doi"])
        record_key = (record.get("version") or 0, record.get("posted") or "")
        current_key = (
            (current.get("version") or 0, current.get("posted") or "")
            if current
            else (-1, "")
        )
        if current is None or record_key > current_key:
            latest[record["doi"]] = record
    return list(latest.values())


def _query_terms(query: str) -> list[str]:
    try:
        terms = shlex.split(query)
    except ValueError as exc:
        raise MedrxivError(f"Invalid keyword quoting: {exc}") from exc
    normalized = [term.casefold() for term in terms if term.strip()]
    if not normalized:
        raise MedrxivError("The keyword query must not be empty")
    return normalized


def _field_text(record: dict[str, Any], field: str) -> str:
    values: list[str | None]
    if field == "title":
        values = [record.get("title")]
    elif field == "abstract":
        values = [record.get("abstract")]
    elif field == "authors":
        values = ["; ".join(record.get("authors") or [])]
    elif field == "title-abstract":
        values = [record.get("title"), record.get("abstract")]
    else:
        values = [
            record.get("title"),
            record.get("abstract"),
            "; ".join(record.get("authors") or []),
            record.get("category"),
        ]
    return " ".join(value for value in values if value).casefold()


def _matches_record(record: dict[str, Any], args: argparse.Namespace) -> bool:
    query = (args.query or "").strip()
    if query:
        haystack = _field_text(record, args.field)
        if args.match == "phrase":
            phrase = " ".join(query.split()).casefold()
            if phrase not in haystack:
                return False
        else:
            matches = [term in haystack for term in _query_terms(query)]
            if args.match == "all" and not all(matches):
                return False
            if args.match == "any" and not any(matches):
                return False

    authors = "; ".join(record.get("authors") or []).casefold()
    if any(author.casefold() not in authors for author in args.author):
        return False
    return True


def _project_record(record: dict[str, Any], mode: str) -> dict[str, Any]:
    minimal_fields = {
        "source",
        "doi",
        "version",
        "versioned_id",
        "title",
        "authors",
        "posted",
        "category",
        "abstract_url",
    }
    compact_fields = minimal_fields | {
        "abstract",
        "published_doi",
        "doi_url",
        "pdf_url",
        "license",
    }
    if mode == "full":
        return record
    selected = minimal_fields if mode == "minimal" else compact_fields
    return {key: value for key, value in record.items() if key in selected}


def _base_output(
    args: argparse.Namespace,
    scan: ScanResult,
    posted_from: str,
    posted_to: str,
) -> dict[str, Any]:
    return {
        "source": "medRxiv",
        "api_endpoint": API_ENDPOINT,
        "api_filter": {
            "posted_from": posted_from,
            "posted_to": posted_to,
            "category": args.category,
        },
        "local_filter": {
            "query": (args.query or "").strip() or None,
            "field": args.field,
            "match": args.match,
            "authors_all": args.author,
        },
        "keyword_filter_location": "local_metadata" if args.query else "none",
        "version_policy": (
            "all_versions" if args.all_versions else "latest_returned_per_doi"
        ),
        "source_total_version_records": scan.source_total_version_records,
        "source_new_papers": scan.source_new_papers,
        "scanned_unique_version_records": len(scan.records),
        "api_pages": scan.api_pages,
        "cache_hits": scan.cache_hits,
        "source_fetched_from_utc": scan.source_fetched_from_utc,
        "source_fetched_through_utc": scan.source_fetched_through_utc,
        "retrieved_at_utc": _iso_utc(),
    }


def _prepare_matches(
    args: argparse.Namespace,
) -> tuple[list[dict[str, Any]], ScanResult, str, str]:
    posted_from, posted_to = _resolve_interval(args)
    client = MedrxivClient(timeout=args.timeout)
    scan = _collect_interval(
        client,
        posted_from,
        posted_to,
        category=args.category,
        max_source_records=args.max_source_records,
        refresh=args.refresh,
    )
    candidates = (
        scan.records if args.all_versions else _latest_returned_per_doi(scan.records)
    )
    matches = [record for record in candidates if _matches_record(record, args)]
    return matches, scan, posted_from, posted_to


def _emit(value: dict[str, Any]) -> None:
    json.dump(value, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


def command_count(args: argparse.Namespace) -> None:
    matches, scan, posted_from, posted_to = _prepare_matches(args)
    output = _base_output(args, scan, posted_from, posted_to)
    output.update({"operation": "count", "matched_records": len(matches)})
    _emit(output)


def command_search(args: argparse.Namespace) -> None:
    if args.start < 0:
        raise MedrxivError("--start must be >= 0")
    if not 0 <= args.retmax <= MAX_RETURNED_RESULTS:
        raise MedrxivError(f"--retmax must be between 0 and {MAX_RETURNED_RESULTS}")
    matches, scan, posted_from, posted_to = _prepare_matches(args)
    reverse = args.sort_order == "descending"
    matches.sort(
        key=lambda item: (
            item.get("posted") or "",
            item.get("doi") or "",
            item.get("version") or 0,
        ),
        reverse=reverse,
    )
    selected = matches[args.start : args.start + args.retmax]
    output = _base_output(args, scan, posted_from, posted_to)
    output.update(
        {
            "operation": "search",
            "sort_by": "posted_date",
            "sort_order": args.sort_order,
            "matched_records": len(matches),
            "start_index": args.start,
            "returned": len(selected),
            "results": [
                _project_record(record, args.output_mode) for record in selected
            ],
        }
    )
    _emit(output)


DOI_PATTERN = re.compile(r"^10\.\d{4,9}/\S+$", flags=re.IGNORECASE)


def _normalize_doi(value: str) -> str:
    original = value
    value = urllib.parse.unquote(value.strip())
    value = re.sub(r"^doi:\s*", "", value, flags=re.IGNORECASE)
    if value.startswith(("http://", "https://")):
        parsed = urllib.parse.urlsplit(value)
        if parsed.hostname in {"doi.org", "dx.doi.org"}:
            value = parsed.path.lstrip("/")
        elif parsed.hostname in {"medrxiv.org", "www.medrxiv.org"} and "/content/" in parsed.path:
            value = parsed.path.split("/content/", 1)[1]
        else:
            raise MedrxivError(f"Unsupported DOI/medRxiv URL: {original}")
    value = value.split("?", 1)[0].split("#", 1)[0].rstrip("/")
    value = re.sub(r"\.(?:full(?:-text)?|abstract|pdf)(?:\.pdf)?$", "", value)
    value = re.sub(r"v\d+$", "", value)
    if not DOI_PATTERN.fullmatch(value):
        raise MedrxivError(f"Invalid DOI: {original}")
    return value


def command_fetch(args: argparse.Namespace) -> None:
    requested = list(dict.fromkeys(_normalize_doi(value) for value in args.dois))
    if len(requested) > 20:
        raise MedrxivError("fetch accepts at most 20 DOIs per run")
    client = MedrxivClient(timeout=args.timeout)
    results: list[dict[str, Any]] = []
    unmatched: list[str] = []
    cache_hits = 0
    fetched_times: list[str] = []
    for doi in requested:
        result = client.doi(doi, refresh=args.refresh)
        cache_hits += int(result.cache_hit)
        fetched_times.append(result.source_fetched_at_utc)
        records = [_record_from_api(raw) for raw in result.parsed["collection"]]
        records = [record for record in records if record["doi"].casefold() == doi.casefold()]
        if not records:
            unmatched.append(doi)
            continue
        if not args.all_versions:
            records = _latest_returned_per_doi(records)
        results.extend(records)

    results.sort(
        key=lambda item: (
            item.get("doi") or "",
            item.get("version") or 0,
            item.get("posted") or "",
        )
    )
    _emit(
        {
            "source": "medRxiv",
            "operation": "fetch",
            "api_endpoint": API_ENDPOINT,
            "requested_dois": requested,
            "version_policy": (
                "all_versions" if args.all_versions else "latest_returned_per_doi"
            ),
            "returned": len(results),
            "unmatched_requested_dois": unmatched,
            "cache_hits": cache_hits,
            "source_fetched_from_utc": min(fetched_times) if fetched_times else None,
            "source_fetched_through_utc": max(fetched_times) if fetched_times else None,
            "retrieved_at_utc": _iso_utc(),
            "results": [
                _project_record(record, args.output_mode) for record in results
            ],
        }
    )


def _query_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("query", nargs="?", help="Keywords filtered locally in metadata")
    parser.add_argument(
        "--field",
        choices=["title-abstract", "title", "abstract", "authors", "all"],
        default="title-abstract",
        help="Metadata field used for local keyword filtering",
    )
    parser.add_argument(
        "--match",
        choices=["all", "any", "phrase"],
        default="all",
        help="Require all terms, any term, or an exact literal phrase",
    )
    parser.add_argument(
        "--author", action="append", default=[], help="Require an author substring; repeat for AND"
    )
    parser.add_argument(
        "--category", help="Official medRxiv subject category filter"
    )
    parser.add_argument("--posted-from", help="Version posting date from YYYY-MM-DD")
    parser.add_argument("--posted-to", help="Version posting date through YYYY-MM-DD")
    parser.add_argument(
        "--days",
        type=int,
        help=f"Most recent N UTC calendar days (default {DEFAULT_LOOKBACK_DAYS})",
    )
    parser.add_argument(
        "--all-versions",
        action="store_true",
        help="Keep every returned version instead of the latest returned version per DOI",
    )
    parser.add_argument(
        "--max-source-records",
        type=int,
        default=DEFAULT_MAX_SOURCE_RECORDS,
        help="Abort before scanning an overly broad API interval",
    )
    parser.add_argument("--timeout", type=float, default=45.0, help=argparse.SUPPRESS)
    parser.add_argument(
        "--refresh", action="store_true", help="Bypass the short-term response cache"
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Search medRxiv metadata from the official API; keyword matching is local"
        )
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    count = subparsers.add_parser("count", help="Count local metadata matches")
    _query_arguments(count)
    count.set_defaults(func=command_count)

    search = subparsers.add_parser("search", help="Search medRxiv metadata")
    _query_arguments(search)
    search.add_argument("--start", type=int, default=0, help="Zero-based match offset")
    search.add_argument(
        "--retmax", type=int, default=20, help="Matches to return, maximum 2000"
    )
    search.add_argument(
        "--sort-order",
        choices=["ascending", "descending"],
        default="descending",
    )
    search.add_argument(
        "--output-mode",
        choices=["minimal", "compact", "full"],
        default="compact",
    )
    search.set_defaults(func=command_search)

    fetch = subparsers.add_parser("fetch", help="Fetch metadata by medRxiv DOI")
    fetch.add_argument("dois", nargs="+", help="DOIs, DOI URLs, or medRxiv URLs")
    fetch.add_argument(
        "--all-versions", action="store_true", help="Return every API version"
    )
    fetch.add_argument(
        "--output-mode",
        choices=["minimal", "compact", "full"],
        default="full",
    )
    fetch.add_argument("--timeout", type=float, default=45.0, help=argparse.SUPPRESS)
    fetch.add_argument(
        "--refresh", action="store_true", help="Bypass the short-term response cache"
    )
    fetch.set_defaults(func=command_fetch)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        args.func(args)
    except (MedrxivError, KeyboardInterrupt) as exc:
        message = "Interrupted" if isinstance(exc, KeyboardInterrupt) else str(exc)
        print(f"ERROR: {message}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
