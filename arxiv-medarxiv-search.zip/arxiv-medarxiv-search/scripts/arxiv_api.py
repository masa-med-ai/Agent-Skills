#!/usr/bin/env python3
"""Small, dependency-free client for the official arXiv query API."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import shlex
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import date, datetime, time as datetime_time, timezone
from pathlib import Path
from typing import Any, Iterable


VERSION = "1.0.0"
API_ENDPOINT = "https://export.arxiv.org/api/query"
USER_AGENT = os.environ.get(
    "ARXIV_USER_AGENT",
    "arxiv-search-skill/1.0 (+https://info.arxiv.org/help/api/user-manual.html)",
)
MIN_REQUEST_INTERVAL_SECONDS = 3.1
CACHE_TTL_SECONDS = 12 * 60 * 60
MAX_SLICE = 2000
MAX_WINDOW = 30000
RETRYABLE_HTTP_CODES = {429, 500, 502, 503, 504}

NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "opensearch": "http://a9.com/-/spec/opensearch/1.1/",
    "arxiv": "http://arxiv.org/schemas/atom",
}


class ArxivError(RuntimeError):
    """Base error shown cleanly by the CLI."""


class ArxivResponseError(ArxivError):
    """Error encoded in an arXiv Atom feed."""


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso_utc(value: datetime | None = None) -> str:
    value = value or _utc_now()
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _normalize_space(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = " ".join(value.split())
    return normalized or None


def _https_arxiv_url(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urllib.parse.urlsplit(value)
    if parsed.hostname in {"arxiv.org", "www.arxiv.org", "export.arxiv.org"}:
        return urllib.parse.urlunsplit(
            ("https", parsed.netloc, parsed.path, parsed.query, parsed.fragment)
        )
    return value


def _integer_text(root: ET.Element, path: str, default: int = 0) -> int:
    raw = root.findtext(path, namespaces=NS)
    try:
        return int(raw) if raw is not None else default
    except ValueError as exc:
        raise ArxivResponseError(f"Invalid integer in Atom feed: {raw!r}") from exc


def _extract_arxiv_id(entry_id: str | None) -> str:
    if not entry_id:
        raise ArxivResponseError("An entry is missing its arXiv identifier")
    marker = "/abs/"
    if marker not in entry_id:
        raise ArxivResponseError(f"Unexpected arXiv entry identifier: {entry_id}")
    return entry_id.split(marker, 1)[1].rstrip("/")


def _entry_to_record(entry: ET.Element) -> dict[str, Any]:
    entry_id = _normalize_space(entry.findtext("atom:id", namespaces=NS))
    entry_arxiv_id = _extract_arxiv_id(entry_id)
    authors: list[str] = []
    author_details: list[dict[str, str | None]] = []
    for author in entry.findall("atom:author", NS):
        name = _normalize_space(author.findtext("atom:name", namespaces=NS))
        if not name:
            continue
        affiliation = _normalize_space(
            author.findtext("arxiv:affiliation", namespaces=NS)
        )
        authors.append(name)
        author_details.append({"name": name, "affiliation": affiliation})

    categories = [
        term
        for category in entry.findall("atom:category", NS)
        if (term := category.attrib.get("term"))
    ]
    primary = entry.find("arxiv:primary_category", NS)
    primary_category = primary.attrib.get("term") if primary is not None else None

    links: list[dict[str, str | None]] = []
    abstract_url: str | None = None
    pdf_url: str | None = None
    for link in entry.findall("atom:link", NS):
        item = {
            "href": _https_arxiv_url(link.attrib.get("href")),
            "rel": link.attrib.get("rel"),
            "type": link.attrib.get("type"),
            "title": link.attrib.get("title"),
        }
        links.append(item)
        if item["rel"] == "alternate" and abstract_url is None:
            abstract_url = item["href"]
        if item["title"] == "pdf" and pdf_url is None:
            pdf_url = item["href"]

    linked_arxiv_id = None
    if abstract_url and "/abs/" in abstract_url:
        linked_arxiv_id = abstract_url.split("/abs/", 1)[1].rstrip("/")
    arxiv_id = linked_arxiv_id or entry_arxiv_id
    base_arxiv_id = re.sub(r"v\d+$", "", arxiv_id)
    version_match = re.search(r"v(\d+)$", arxiv_id)
    version = int(version_match.group(1)) if version_match else None
    abstract_url = abstract_url or f"https://arxiv.org/abs/{arxiv_id}"
    pdf_url = pdf_url or f"https://arxiv.org/pdf/{arxiv_id}"
    return {
        "arxiv_id": arxiv_id,
        "base_arxiv_id": base_arxiv_id,
        "version": version,
        "title": _normalize_space(entry.findtext("atom:title", namespaces=NS)),
        "authors": authors,
        "author_details": author_details,
        "abstract": _normalize_space(entry.findtext("atom:summary", namespaces=NS)),
        "published": _normalize_space(entry.findtext("atom:published", namespaces=NS)),
        "updated": _normalize_space(entry.findtext("atom:updated", namespaces=NS)),
        "primary_category": primary_category,
        "categories": categories,
        "doi": _normalize_space(entry.findtext("arxiv:doi", namespaces=NS)),
        "journal_ref": _normalize_space(
            entry.findtext("arxiv:journal_ref", namespaces=NS)
        ),
        "comment": _normalize_space(entry.findtext("arxiv:comment", namespaces=NS)),
        "abstract_url": abstract_url,
        "pdf_url": pdf_url,
        "links": links,
    }


def parse_atom_feed(payload: bytes) -> dict[str, Any]:
    try:
        root = ET.fromstring(payload)
    except ET.ParseError as exc:
        preview = payload[:240].decode("utf-8", errors="replace")
        raise ArxivResponseError(f"arXiv returned invalid Atom XML: {preview}") from exc

    if root.tag != f"{{{NS['atom']}}}feed":
        raise ArxivResponseError(f"Unexpected Atom root element: {root.tag}")

    entries = root.findall("atom:entry", NS)
    if len(entries) == 1:
        title = _normalize_space(entries[0].findtext("atom:title", namespaces=NS))
        entry_id = (
            _normalize_space(entries[0].findtext("atom:id", namespaces=NS)) or ""
        )
        if title == "Error" or "/api/errors#" in entry_id:
            summary = _normalize_space(
                entries[0].findtext("atom:summary", namespaces=NS)
            )
            raise ArxivResponseError(
                summary or "arXiv returned an unspecified API error"
            )

    return {
        "feed": {
            "title": _normalize_space(root.findtext("atom:title", namespaces=NS)),
            "id": _normalize_space(root.findtext("atom:id", namespaces=NS)),
            "updated": _normalize_space(root.findtext("atom:updated", namespaces=NS)),
            "total_results": _integer_text(root, "opensearch:totalResults"),
            "start_index": _integer_text(root, "opensearch:startIndex"),
            "items_per_page": _integer_text(root, "opensearch:itemsPerPage"),
        },
        "entries": [_entry_to_record(entry) for entry in entries],
    }


@dataclass(frozen=True)
class ApiResult:
    parsed: dict[str, Any]
    request_url: str
    cache_hit: bool
    source_fetched_at_utc: str


class ArxivClient:
    def __init__(
        self,
        *,
        api_endpoint: str = API_ENDPOINT,
        timeout: float = 45.0,
        max_retries: int = 3,
        cache_ttl: float = CACHE_TTL_SECONDS,
        cache_dir: Path | None = None,
        rate_state: Path | None = None,
    ) -> None:
        self.api_endpoint = api_endpoint
        self.timeout = timeout
        self.max_retries = max_retries
        self.cache_ttl = cache_ttl
        temp_root = Path(tempfile.gettempdir())
        self.cache_dir = cache_dir or temp_root / "arxiv-search-cache"
        self.rate_state = rate_state or temp_root / "arxiv-search-rate-limit"

    def query(
        self, params: dict[str, str | int], *, refresh: bool = False
    ) -> ApiResult:
        query_string = urllib.parse.urlencode(params)
        request_url = f"{self.api_endpoint}?{query_string}"
        if len(request_url) > 8000:
            raise ArxivError("Query URL is too long; simplify or split the search expression")

        cache_path = self._cache_path(request_url)
        if not refresh:
            cached = self._read_cache(cache_path)
            if cached is not None:
                payload, fetched_at = cached
                try:
                    return ApiResult(
                        parse_atom_feed(payload), request_url, True, fetched_at
                    )
                except ArxivResponseError:
                    try:
                        cache_path.unlink()
                    except OSError:
                        pass

        payload = self._request_with_retries(request_url)
        fetched_at = _iso_utc()
        self._write_cache(cache_path, payload)
        return ApiResult(parse_atom_feed(payload), request_url, False, fetched_at)

    def _cache_path(self, request_url: str) -> Path:
        digest = hashlib.sha256(request_url.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{digest}.atom"

    def _read_cache(self, path: Path) -> tuple[bytes, str] | None:
        try:
            stat = path.stat()
            if time.time() - stat.st_mtime > self.cache_ttl:
                return None
            payload = path.read_bytes()
            fetched_at = _iso_utc(
                datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
            )
            return payload, fetched_at
        except (FileNotFoundError, OSError):
            return None

    def _write_cache(self, path: Path, payload: bytes) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            handle, temp_name = tempfile.mkstemp(prefix=".arxiv-", dir=path.parent)
            try:
                with os.fdopen(handle, "wb") as stream:
                    stream.write(payload)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temp_name, path)
            finally:
                try:
                    os.unlink(temp_name)
                except FileNotFoundError:
                    pass
        except OSError:
            # A cache failure must not turn a successful API request into a search failure.
            return

    def _request_with_retries(self, request_url: str) -> bytes:
        last_error: BaseException | None = None
        for attempt in range(self.max_retries + 1):
            try:
                return self._throttled_get(request_url)
            except urllib.error.HTTPError as exc:
                last_error = exc
                body_bytes = exc.read(65536)
                try:
                    parse_atom_feed(body_bytes)
                except ArxivResponseError as feed_error:
                    detail = str(feed_error)
                else:
                    detail = body_bytes[:500].decode("utf-8", errors="replace")
                if exc.code not in RETRYABLE_HTTP_CODES or attempt >= self.max_retries:
                    raise ArxivError(
                        f"arXiv HTTP {exc.code}: {detail or exc.reason}"
                    ) from exc
                retry_after = exc.headers.get("Retry-After")
                delay = self._retry_delay(attempt, retry_after)
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    raise ArxivError(f"Unable to reach arXiv API: {exc}") from exc
                delay = max(MIN_REQUEST_INTERVAL_SECONDS, 2 ** attempt)
            time.sleep(delay)
        raise ArxivError(f"Unable to reach arXiv API: {last_error}")

    @staticmethod
    def _retry_delay(attempt: int, retry_after: str | None) -> float:
        if retry_after:
            try:
                return min(
                    60.0,
                    max(MIN_REQUEST_INTERVAL_SECONDS, float(retry_after)),
                )
            except ValueError:
                pass
        return min(60.0, max(MIN_REQUEST_INTERVAL_SECONDS, 2 ** attempt))

    def _throttled_get(self, request_url: str) -> bytes:
        self.rate_state.parent.mkdir(parents=True, exist_ok=True)
        with self.rate_state.open("a+", encoding="utf-8") as state:
            fcntl.flock(state.fileno(), fcntl.LOCK_EX)
            try:
                state.seek(0)
                raw = state.read().strip()
                try:
                    last_finished = float(raw) if raw else 0.0
                except ValueError:
                    last_finished = 0.0
                wait_for = MIN_REQUEST_INTERVAL_SECONDS - (time.time() - last_finished)
                if wait_for > 0:
                    time.sleep(wait_for)

                request = urllib.request.Request(
                    request_url,
                    headers={
                        "User-Agent": USER_AGENT,
                        "Accept": "application/atom+xml",
                    },
                    method="GET",
                )
                try:
                    with urllib.request.urlopen(
                        request, timeout=self.timeout
                    ) as response:
                        return response.read()
                finally:
                    state.seek(0)
                    state.truncate()
                    state.write(str(time.time()))
                    state.flush()
                    os.fsync(state.fileno())
            finally:
                fcntl.flock(state.fileno(), fcntl.LOCK_UN)


def _quote_term(value: str) -> str:
    value = value.strip()
    if not value:
        raise ArxivError("Search terms must not be empty")
    if '"' in value:
        raise ArxivError(
            'A non-raw search term must not contain a double quote; use --raw instead'
        )
    if re.fullmatch(r"[\w.+-]+", value, flags=re.UNICODE):
        return value
    return f'"{value}"'


def _keyword_expression(query: str, field: str, match: str) -> str:
    query = query.strip()
    if not query:
        raise ArxivError("A keyword query or at least one filter is required")
    if match == "phrase":
        return f"{field}:{_quote_term(query)}"
    try:
        terms = shlex.split(query)
    except ValueError as exc:
        raise ArxivError(f"Invalid keyword quoting: {exc}") from exc
    if not terms:
        raise ArxivError("A keyword query or at least one filter is required")
    operator = " AND " if match == "all" else " OR "
    expressions = [f"{field}:{_quote_term(term)}" for term in terms]
    return expressions[0] if len(expressions) == 1 else f"({operator.join(expressions)})"


def _parse_date(value: str, label: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ArxivError(f"{label} must be YYYY-MM-DD: {value}") from exc


def _submitted_date_expression(start: str | None, end: str | None) -> str | None:
    if not start and not end:
        return None
    start_date = _parse_date(start, "--submitted-from") if start else date(1991, 1, 1)
    end_date = _parse_date(end, "--submitted-to") if end else _utc_now().date()
    if start_date > end_date:
        raise ArxivError("--submitted-from must not be after --submitted-to")
    start_dt = datetime.combine(
        start_date, datetime_time(0, 0), tzinfo=timezone.utc
    )
    end_dt = datetime.combine(end_date, datetime_time(23, 59), tzinfo=timezone.utc)
    return f"submittedDate:[{start_dt:%Y%m%d%H%M} TO {end_dt:%Y%m%d%H%M}]"


def build_search_query(args: argparse.Namespace) -> str:
    expressions: list[str] = []
    raw_query = (args.query or "").strip()
    if args.raw:
        if args.field != "all" or args.match != "all":
            raise ArxivError("--field and --match cannot be combined with --raw")
        if raw_query:
            expressions.append(f"({raw_query})")
    elif raw_query:
        expressions.append(_keyword_expression(raw_query, args.field, args.match))

    for author in args.author:
        expressions.append(f"au:{_quote_term(author)}")

    if args.category:
        categories: list[str] = []
        for category in args.category:
            if not re.fullmatch(r"[A-Za-z0-9.-]+", category):
                raise ArxivError(f"Invalid arXiv category: {category}")
            categories.append(f"cat:{category}")
        category_expression = " OR ".join(categories)
        expressions.append(
            categories[0] if len(categories) == 1 else f"({category_expression})"
        )

    date_expression = _submitted_date_expression(
        args.submitted_from, args.submitted_to
    )
    if date_expression:
        expressions.append(date_expression)

    if not expressions:
        raise ArxivError(
            "A keyword query or at least one author/category/date filter is required"
        )
    return " AND ".join(expressions)


def _validate_window(start: int, retmax: int) -> None:
    if start < 0:
        raise ArxivError("--start must be >= 0")
    if not 0 <= retmax <= MAX_SLICE:
        raise ArxivError(f"--retmax must be between 0 and {MAX_SLICE}")
    if start + retmax > MAX_WINDOW:
        raise ArxivError(f"The requested slice must end at or before {MAX_WINDOW}")


def _base_output(api_result: ApiResult, search_query: str | None) -> dict[str, Any]:
    feed = api_result.parsed["feed"]
    return {
        "search_query": search_query,
        "request_url": api_result.request_url,
        "retrieved_at_utc": _iso_utc(),
        "source_fetched_at_utc": api_result.source_fetched_at_utc,
        "cache_hit": api_result.cache_hit,
        "total_results": feed["total_results"],
        "start_index": feed["start_index"],
        "items_per_page": feed["items_per_page"],
        "feed_updated": feed["updated"],
    }


def _project_record(record: dict[str, Any], mode: str) -> dict[str, Any]:
    minimal_fields = {
        "arxiv_id",
        "base_arxiv_id",
        "version",
        "title",
        "authors",
        "published",
        "updated",
        "primary_category",
        "abstract_url",
    }
    compact_fields = minimal_fields | {
        "abstract",
        "categories",
        "doi",
        "journal_ref",
        "comment",
        "pdf_url",
    }
    if mode == "full":
        return record
    selected = minimal_fields if mode == "minimal" else compact_fields
    return {key: value for key, value in record.items() if key in selected}


def _emit(value: dict[str, Any]) -> None:
    json.dump(value, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


def _query_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "query", nargs="?", help="Plain keywords, or an arXiv expression with --raw"
    )
    parser.add_argument(
        "--raw", action="store_true", help="Treat query as native arXiv search_query syntax"
    )
    parser.add_argument(
        "--field",
        choices=["all", "ti", "au", "abs", "co", "jr", "cat", "rn"],
        default="all",
        help="Field used for plain keywords (default: all)",
    )
    parser.add_argument(
        "--match",
        choices=["all", "any", "phrase"],
        default="all",
        help="Require all words, any word, or the exact phrase (default: all)",
    )
    parser.add_argument(
        "--author", action="append", default=[], help="Require an author; repeat for AND"
    )
    parser.add_argument(
        "--category", action="append", default=[], help="Allow a category; repeat for OR"
    )
    parser.add_argument(
        "--submitted-from", help="First submission date from YYYY-MM-DD UTC"
    )
    parser.add_argument(
        "--submitted-to", help="First submission date through YYYY-MM-DD UTC"
    )


def _client_from_args(args: argparse.Namespace) -> ArxivClient:
    return ArxivClient(timeout=args.timeout)


def command_count(args: argparse.Namespace) -> None:
    search_query = build_search_query(args)
    result = _client_from_args(args).query(
        # The documented API accepts zero, but the live legacy endpoint can
        # return an error feed for max_results=0. Fetch one record and read
        # opensearch:totalResults for a compatible count probe.
        {"search_query": search_query, "start": 0, "max_results": 1},
        refresh=args.refresh,
    )
    output = _base_output(result, search_query)
    output["operation"] = "count"
    output["count_probe_records_returned"] = len(result.parsed["entries"])
    _emit(output)


def command_search(args: argparse.Namespace) -> None:
    _validate_window(args.start, args.retmax)
    search_query = build_search_query(args)
    params: dict[str, str | int] = {
        "search_query": search_query,
        "start": args.start,
        "max_results": args.retmax,
        "sortBy": args.sort_by,
        "sortOrder": args.sort_order,
    }
    result = _client_from_args(args).query(params, refresh=args.refresh)
    output = _base_output(result, search_query)
    output.update(
        {
            "operation": "search",
            "sort_by": args.sort_by,
            "sort_order": args.sort_order,
            "returned": len(result.parsed["entries"]),
            "results": [
                _project_record(record, args.output_mode)
                for record in result.parsed["entries"]
            ],
        }
    )
    _emit(output)


MODERN_ID = re.compile(r"^\d{4}\.\d{4,5}(?:v\d+)?$")
LEGACY_ID = re.compile(r"^[A-Za-z][A-Za-z0-9.-]*/\d{7}(?:v\d+)?$")


def _normalize_arxiv_id(value: str) -> str:
    value = value.strip()
    value = re.sub(r"^arXiv:\s*", "", value, flags=re.IGNORECASE)
    if "/abs/" in value:
        value = value.split("/abs/", 1)[1]
    elif "/pdf/" in value:
        value = value.split("/pdf/", 1)[1]
    value = value.split("?", 1)[0].split("#", 1)[0].rstrip("/")
    if value.endswith(".pdf"):
        value = value[:-4]
    if not (MODERN_ID.fullmatch(value) or LEGACY_ID.fullmatch(value)):
        raise ArxivError(f"Invalid arXiv ID: {value}")
    return value


def command_fetch(args: argparse.Namespace) -> None:
    ids = list(dict.fromkeys(_normalize_arxiv_id(value) for value in args.ids))
    if len(ids) > 100:
        raise ArxivError("fetch accepts at most 100 IDs per request")
    result = _client_from_args(args).query(
        {"id_list": ",".join(ids), "start": 0, "max_results": len(ids)},
        refresh=args.refresh,
    )
    output = _base_output(result, None)
    returned_ids = {
        record["arxiv_id"] for record in result.parsed["entries"]
    } | {
        record["base_arxiv_id"] for record in result.parsed["entries"]
    }
    output.update(
        {
            "operation": "fetch",
            "requested_ids": ids,
            "returned": len(result.parsed["entries"]),
            "unmatched_requested_ids": [
                value for value in ids if value not in returned_ids
            ],
            "results": [
                _project_record(record, args.output_mode)
                for record in result.parsed["entries"]
            ],
        }
    )
    _emit(output)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Search the official arXiv Atom API")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    count = subparsers.add_parser(
        "count", help="Count matches for a reproducible query"
    )
    _query_arguments(count)
    count.add_argument("--timeout", type=float, default=45.0, help=argparse.SUPPRESS)
    count.add_argument(
        "--refresh", action="store_true", help="Bypass the short-term response cache"
    )
    count.set_defaults(func=command_count)

    search = subparsers.add_parser("search", help="Search and return arXiv metadata")
    _query_arguments(search)
    search.add_argument("--start", type=int, default=0, help="Zero-based result offset")
    search.add_argument(
        "--retmax", type=int, default=20, help="Results to return, maximum 2000"
    )
    search.add_argument(
        "--sort-by",
        choices=["relevance", "lastUpdatedDate", "submittedDate"],
        default="relevance",
    )
    search.add_argument(
        "--sort-order",
        choices=["ascending", "descending"],
        default="descending",
    )
    search.add_argument(
        "--output-mode",
        choices=["minimal", "compact", "full"],
        default="compact",
    )
    search.add_argument("--timeout", type=float, default=45.0, help=argparse.SUPPRESS)
    search.add_argument(
        "--refresh", action="store_true", help="Bypass the short-term response cache"
    )
    search.set_defaults(func=command_search)

    fetch = subparsers.add_parser("fetch", help="Fetch metadata by arXiv ID")
    fetch.add_argument("ids", nargs="+", help="arXiv IDs or abstract/PDF URLs")
    fetch.add_argument(
        "--output-mode",
        choices=["minimal", "compact", "full"],
        default="full",
    )
    fetch.add_argument("--timeout", type=float, default=45.0, help=argparse.SUPPRESS)
    fetch.add_argument(
        "--refresh", action="store_true", help="Bypass the short-term response cache"
    )
    fetch.set_defaults(func=command_fetch)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    try:
        args.func(args)
    except (ArxivError, KeyboardInterrupt) as exc:
        message = "Interrupted" if isinstance(exc, KeyboardInterrupt) else str(exc)
        print(f"ERROR: {message}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
