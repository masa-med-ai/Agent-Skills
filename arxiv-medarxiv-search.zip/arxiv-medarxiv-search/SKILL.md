---
name: arxiv-medarxiv-search
description: arXivとmedRxivのプレプリント・e-printを公式APIから検索し、キーワード、完全一致フレーズ、著者、カテゴリ、投稿日、arXiv ID、medRxiv DOIを使った再現可能な検索式・条件と、原文リンク付きの選定結果を返す。「arXivで論文を探して」「medRxiv（MedArxiv）を検索」「医療プレプリントを探して」「最新のプレプリント」「arXiv ID／medRxiv DOIの論文情報」と依頼された一般的なプレプリント検索で使用する。PubMed、査読済み文献だけの検索、複数データベースを横断する系統的レビューには使用しない。
---

# arXiv / medRxiv Search

公式APIを使い、検索元と検索過程を追跡できるプレプリント検索を行う。

## 必須backend

検索元に応じて次を読む。API検索とメタデータ取得には対応する同梱CLIだけを使い、一般Web検索をAPI検索の代用にせず、記憶から書誌情報を補わない。

| Source | 必須reference | CLI |
|---|---|---|
| arXiv | `references/arxiv-api.md` | `scripts/arxiv_api.py` |
| medRxiv | `references/medrxiv-api.md` | `scripts/medrxiv_api.py` |

各CLIの絶対パスは、読み込まれた`SKILL.md`の絶対パスから解決する。どちらもAPIキーは不要で、単一接続、間隔制御、再試行、短期キャッシュを処理する。

医療・健康科学の問いで検索元が指定されなければ、arXivとmedRxivの両方が有用かを判断する。両方を使う場合はAPIを別々に実行し、検索条件・件数・結果のprovenanceをsource別に保つ。source間の件数や順位を単純合算しない。

## 共通の出力契約

- 実際に取得したレコードだけを示す。タイトル、著者、識別子、日付、カテゴリ、DOI、journal referenceを記憶で補わない。
- source、検索条件、検索日、総件数、取得・走査範囲、並び順、選択基準、abstractのみで判断した箇所を併記する。
- 0件なら、その事実と試した条件を示す。架空の代替文献を出さない。
- DOIやjournal referenceがレコードにある場合だけ記載する。存在しても査読済み、最新版、研究の質を断定しない。
- abstractにない方法・数値・結論は「記載なし」とする。本文が必要ならabstractページまたはPDFへリンクし、著作権とライセンスを尊重する。

### arXiv citation

各文献を次のMarkdown形式で示す。

    [*Title*](https://arxiv.org/abs/ARXIV_ID) — First Author et al. / Sole Author, arXiv:ARXIV_ID (Primary Category), first submitted YYYY-MM-DD; updated YYYY-MM-DD

著者が1名なら`et al.`を付けず、複数なら筆頭著者の後を`et al.`とする。`published`は初回投稿、`updated`は取得版の更新日として区別し、版番号付きIDは保持する。

### medRxiv citation

各文献を次のMarkdown形式で示す。

    [*Title*](https://www.medrxiv.org/content/DOIvN) — First Author et al. / Sole Author, medRxiv DOI:DOI, version N, posted YYYY-MM-DD (Category)

APIの`published_doi`があるときだけ「対応する出版論文DOI」として追記する。`posted`はその版の投稿日であり、初版日とは限らない。

## ワークフロー

1. 問いを概念へ分解し、日本語を英語の専門用語、綴り違い、略語へ展開する。MeSH検索ではないため、必要な同義語を明示する。
2. sourceを選ぶ。arXiv指定ならarXiv、medRxiv指定ならmedRxivを使う。医療分野の横断的プレプリント検索なら両方を別々に実行する。
3. `count`を先に実行し、実際の条件と件数を確認する。0件なら同義語・field・期間を広げ、大量ならカテゴリ、title/abstract、日付で絞る。
4. 初回は`search`で20〜50件を取得する。sourceごとの検索・並び順の制約を守る。
5. inclusion/exclusion criteriaに照らして候補を選ぶ。タイトルだけで判断できない候補はabstractを読む。
6. 続きを取得するときは同じ条件と並び順を保ち、offsetだけを進める。arXivはbase ID、medRxivはDOIとversionで重複を管理する。
7. 既知の識別子は、arXiv IDならarXiv CLI、medRxiv DOIならmedRxiv CLIの`fetch`を使う。
8. 結論、検索上の限界、preprintである点をまとめ、source別のcitation形式で提示する。

## arXiv commands and rules

以下の`ARXIV`は`arxiv_api.py`の絶対パスを表す。

    python3 ARXIV count 'large language models medical imaging'
    python3 ARXIV search 'large language models medical imaging' --retmax 30 --sort-by relevance --output-mode compact
    python3 ARXIV search 'retrieval augmented generation' --match phrase --category cs.AI --retmax 20
    python3 ARXIV search '(ti:"large language model" OR abs:"large language model") AND cat:cs.AI' --raw --submitted-from 2025-01-01 --sort-by submittedDate --sort-order descending
    python3 ARXIV search 'quantum error correction' --start 30 --retmax 30 --sort-by relevance
    python3 ARXIV fetch 1706.03762 2005.14165v4

平文キーワードは各語を`AND`結合して`all:`検索する。いずれかの語なら`--match any`、完全一致なら`--match phrase`を使う。arXiv固有の論理式は`--raw`で渡す。

- 探索的検索では`all:`を使い、ノイズを抑えるときは`ti:`と`abs:`をORで束ねる。
- 同義語はOR、異なる概念はAND、除外はANDNOTで結び、優先順位を丸括弧で明示する。
- 著者名は`au:`、カテゴリは`cat:`を使う。複数の`--category`はOR、複数の`--author`はANDとして扱う。
- 日付指定は初回投稿日に対するUTCの`submittedDate`であり、更新日filterではない。
- 同じ検索を続けるときは式とsortを固定し、`--start`だけを進める。1回は最大2,000件、先頭30,000件までとし、大量なら検索式を狭める。
- arXiv IDは`fetch`で取得し、特定版が必要なら`vN`を付ける。`id:`検索で代用しない。

## medRxiv commands and rules

以下の`MEDRXIV`は`medrxiv_api.py`の絶対パスを表す。

    python3 MEDRXIV count 'large language model' --match phrase --posted-from 2026-01-01 --posted-to 2026-08-16
    python3 MEDRXIV search 'large language model' --match phrase --posted-from 2026-01-01 --posted-to 2026-08-16 --retmax 30 --output-mode compact
    python3 MEDRXIV search 'colorectal cancer screening' --match all --category 'gastroenterology' --days 90 --retmax 20
    python3 MEDRXIV search 'diabetes obesity' --match any --field title-abstract --days 30 --sort-order descending
    python3 MEDRXIV fetch 10.1101/2020.09.09.20191205 10.64898/2026.08.11.26359368

medRxivの公式details APIは汎用キーワード検索を提供しない。CLIは期間と任意のsubject categoryで公式メタデータを取得した後、title/abstract/authorsを大文字小文字を区別しないliteral substringでローカル絞り込みする。この事実を出力で明示する。

- `--match all`は全語、`--match any`はいずれかの語、`--match phrase`は文字列どおりの連続フレーズを要求する。stemming、MeSH、意味検索ではない。
- 日付を省略した場合は直近30 UTC暦日を使う。再現可能な報告では解決後の開始日・終了日を必ず示す。
- APIの`date`はversion投稿日である。既定では取得範囲内の各DOIについて最大versionだけを残し、版ごとの変化が必要なら`--all-versions`を使う。
- API側relevance rankingはない。CLIはversion投稿日でローカルに並べ替える。
- 広すぎる期間は`--max-source-records`で停止する。まず期間またはcategoryを狭め、上限を上げる場合は取得量を確認する。
- APIの総version件数、走査件数、ローカル一致件数を区別して報告する。

## 精度と安全

- arXiv・medRxiv収載は査読済みであることを意味しない。preprintである点、版、投稿日、更新日を必要に応じて明示する。
- 検索順位や新しさを研究の質の指標として扱わない。
- source間で同じ研究と思われても、識別子や書誌情報だけで同一と断定しない。統合するなら根拠を示し、元レコードのprovenanceを保持する。
- APIエラー、通信失敗、検索語の限界、0件を「該当文献なし」の確証へすり替えない。
