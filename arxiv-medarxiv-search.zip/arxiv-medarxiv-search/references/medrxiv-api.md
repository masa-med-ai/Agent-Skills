# medRxiv API reference

このリファレンスは、公式の[bioRxiv/medRxiv API](https://api.biorxiv.org/)と[medRxiv machine access案内](https://www.medrxiv.org/tdm)に基づく（確認日: 2026-08-16）。仕様変更が疑われる場合は公式文書を再確認する。

## Endpoint and response

- CLIが使うendpoint: `https://api.biorxiv.org/details/medrxiv`
- 期間取得: `/YYYY-MM-DD/YYYY-MM-DD/CURSOR/json`
- DOI取得: `/DOI/na/json`
- 期間取得は`?category=SUBJECT`でmedRxiv subject categoryを1つ指定できる。
- 応答はJSONで、`messages[0]`に`status`、`cursor`、`count`、`count_new_papers`、`total`など、`collection`に文献レコードが入る。
- 複数レコードの応答は現在1ページ30件。CLIは`cursor`を進めて逐次取得する。
- 公式説明には「直近N件」「直近Nd日」のintervalも記載されているが、live endpointでは日付エラーになる場合がある。再現性のためCLIは明示的な開始日・終了日だけを使う。

## Metadata

レコードには次の要素が含まれ得る。

- `doi`, `title`, `authors`, `abstract`
- `author_corresponding`, `author_corresponding_institution`
- `date`, `version`, `category`, `type`, `license`
- `jatsxml`, `funder`または`funding`
- `published`, `server`

`date`はその版の投稿日であり、同じDOIについて複数版が返る。`published`は対応する出版論文のDOIまたは`NA`になり得る。値があることだけで査読状況、研究の質、最新版との一致を断定しない。

## Search behavior

公式details APIはarXiv APIの`search_query`に相当する汎用キーワード検索を提供しない。CLIは次の順序で検索する。

1. 期間と任意のsubject categoryを公式APIへ送り、該当メタデータを全ページ取得する。
2. 取得したtitle、abstract、authors、categoryに対し、大文字小文字を区別しないliteral substring matchingをローカルで行う。
3. 既定では、取得範囲内で各DOIの最大versionだけを残す。`--all-versions`なら全版を保持する。
4. `date`でローカルに並べ替え、指定範囲を返す。

この絞り込みにはstemming、語形変化、MeSH、意味検索、API側relevance rankingがない。同義語・綴り違い・略語は検索者がOR相当の`--match any`または複数検索で展開する。広い期間はAPI取得量が増えるため、日付またはcategoryで絞る。

## DOI and versions

- 2025年12月より前の多くのDOIは`10.1101/...`、2025年12月以後の新規DOIは`10.64898/...`を使う。既存DOIは変更されない。背景は公式の[DOI案内](https://connect.medrxiv.org/news/2025/11/18/preprint_dois)を参照する。
- 1つのpreprint DOIを全版で共有し、abstract URLではDOI末尾に`vN`を付けて版を識別する。
- CLIの`fetch`は旧・新の両prefixを受け付け、既定ではAPIが返した最大version、`--all-versions`では全版を返す。

## Paging, caching, and failures

- CLIは単一接続でページを順番に取得し、リクエスト間隔を空け、再試行と12時間の短期キャッシュを使う。
- 初回ページの`total`が`--max-source-records`を超えたら、意図しない大量取得を避けるため停止する。日付・categoryを狭めるか、必要性を確認して上限を明示的に上げる。
- ページング中に新規投稿・改訂が入ると結果集合が変わり得る。取得日時、API総件数、走査件数、ページ数を結果に残す。
- APIエラー、通信失敗、0件を「文献が存在しない」確証へすり替えない。
