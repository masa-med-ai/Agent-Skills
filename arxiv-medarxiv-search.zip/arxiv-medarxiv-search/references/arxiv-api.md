# arXiv API reference

このリファレンスは、arXiv公式の[API User's Manual](https://info.arxiv.org/help/api/user-manual.html)と[Terms of Use for arXiv APIs](https://info.arxiv.org/help/api/tou.html)に基づく（確認日: 2026-08-16）。仕様変更が疑われる場合は公式文書を再確認する。

## Endpoint and response

- Endpoint: `https://export.arxiv.org/api/query`
- GET parameters: `search_query`, `id_list`, `start`, `max_results`, `sortBy`, `sortOrder`
- Response: Atom 1.0 XML with OpenSearch and arXiv extensions.
- `opensearch:totalResults`は総件数、`startIndex`は0始まり、`itemsPerPage`は返却件数を表す。
- Entryにはtitle、abstract (`summary`)、authors、categories、primary category、初回投稿日 (`published`)、取得版更新日 (`updated`)が含まれる。DOI、journal reference、comment、affiliationは任意。

## Search fields

| Prefix | Field |
|---|---|
| `ti` | Title |
| `au` | Author |
| `abs` | Abstract |
| `co` | Comment |
| `jr` | Journal reference |
| `cat` | Subject category |
| `rn` | Report number |
| `all` | All searchable fields |

IDは`id:`ではなく`id_list`を使う。CLIでは`fetch`がこれを行う。

## Query grammar

- Boolean operators: `AND`, `OR`, `ANDNOT`
- Grouping: `( ... )`
- Exact phrase: `ti:"quantum criticality"`
- Example: `(ti:"large language model" OR abs:"large language model") AND cat:cs.AI`
- Author example: `au:del_maestro`
- Submitted-date filter: `submittedDate:[202501010000 TO 202512312359]`（GMT/UTC、分単位）

URLエンコードはCLIに任せ、完成済みのURLではなく未エンコードの検索式を引数に渡す。

## Sorting and paging

- `sortBy`: `relevance`, `lastUpdatedDate`, `submittedDate`
- `sortOrder`: `ascending`, `descending`
- `start`は0始まり。
- 1リクエストの`max_results`は最大2,000件。APIで辿れるのは先頭30,000件まで。
- 1,000件を超える結果は、可能ならクエリを絞り、小さなsliceで取得する。
- 同じ検索式をページングするときは、検索式とsort指定を固定する。APIはPubMed Historyのようなsnapshot tokenを提供しないため、更新をまたぐ長時間のページングでは結果集合が変化し得る。

## Versions

- versionなしID（例: `1706.03762`）は最新版を返す。
- version付きID（例: `1706.03762v1`）は特定版を返す。
- `published`はv1の投稿日、`updated`は返された版の更新日。

## Rate and use limits

- legacy arXiv APIは、管理下の全マシンを通じて3秒に1回以下、単一接続で利用する。
- rate limitを複数接続・複数マシンで回避しない。
- 同一クエリの結果は頻繁に変わらないためキャッシュする。CLIは短期キャッシュを使う。
- descriptive metadataは利用できるが、PDFやsourceの再配布可否は各論文の著作権・ライセンスに従う。
- 大規模metadata収集にはquery APIではなくOAI-PMHや公式bulk accessを検討する。
