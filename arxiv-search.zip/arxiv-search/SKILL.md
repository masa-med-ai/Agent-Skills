---
name: arxiv-search
description: arXivのプレプリント・e-printを公式APIで検索し、キーワード、完全一致フレーズ、著者、タイトル、抄録、カテゴリ、投稿日、arXiv IDを組み合わせた再現可能な検索式と、arXivリンク付きの選定結果を返す。「arXivで論文を探して」「プレプリントを検索」「最新のarXiv文献」「arXiv IDの論文情報」「AI・物理・数学などのe-printを調べて」と依頼された一般的なarXiv文献検索で使用する。PubMed、査読済み文献だけの検索、複数データベースを横断する系統的レビューには使用しない。
---

# arXiv Search

公式arXiv APIを使い、検索過程を追跡できる文献検索を行う。

## 必須backend

同梱の`references/arxiv-api.md`を読み、arXivの検索とメタデータ取得には同梱CLIだけを使う。一般Web検索をarXiv API検索の代用にせず、記憶から書誌情報を補わない。

CLIは、この`SKILL.md`から見た次の相対位置にある。

    scripts/arxiv_api.py

実行時は読み込まれた`SKILL.md`の絶対パスからCLIの絶対パスを解決する。APIキーは不要。CLIが単一接続、3秒以上の間隔、再試行、短期キャッシュを処理する。

## 出力契約

- 実際に取得したレコードだけを示す。タイトル、著者、arXiv ID、日付、カテゴリ、DOI、journal referenceを記憶で補わない。
- 各文献を次のMarkdown形式で示す。

    [*Title*](https://arxiv.org/abs/ARXIV_ID) — First Author et al. / Sole Author, arXiv:ARXIV_ID (Primary Category), first submitted YYYY-MM-DD; updated YYYY-MM-DD

  著者が1名なら`et al.`を付けず、複数なら筆頭著者の後を`et al.`とする。

- 検索式、検索日、総ヒット数、取得範囲、並び順、選択基準、abstractのみで判断した箇所を併記する。
- `published`は初回投稿、`updated`は取得版の更新日として区別する。版番号があるIDは保持する。
- DOIとjournal referenceはAPIレコードに存在するときだけ記載する。存在しても査読済みとは断定しない。
- 0件なら、その事実と試した検索式を示す。架空の代替文献を出さない。

## ワークフロー

1. 問いを概念へ分解し、必要なら日本語を英語の専門用語・綴り違い・略語へ展開する。arXivにはMeSHがないため、分野に合う自由語とカテゴリを使う。
2. `count`を先に実行し、実際の`search_query`と総ヒット数を確認する。0件なら同義語やフィールドを広げ、1,000件超ならカテゴリ、タイトル・抄録、日付で絞る。
3. 初回は`search`で20〜50件を取得する。関連性重視なら`relevance`、新着重視なら`submittedDate --sort-order descending`を使う。
4. inclusion/exclusion criteriaに照らして候補を選ぶ。タイトルだけで判断できない候補はabstractを読む。
5. 続きを取得するときは同じ検索式・並び順を保ち、`--start`だけを進める。重複arXiv IDを除く。
6. 既知のarXiv IDは`fetch`で取得する。特定版が必要なら`vN`を付ける。
7. 結論と限界をまとめ、上記の出力契約で提示する。

## IPブロック時のフォールバック

単純なクエリ（CDNキャッシュ済み）は成功するのに新規クエリが一貫してHTTP 429になる場合、実行環境の共有egress IPがarXiv originにレート制限されている。この状態はCLI側では回避できない。次の順で対応する。

1. `--max-retries 0`の単発プローブで2〜3分おきに2回まで確認する。連射しない。
2. 回復しなければ、web_searchツール（別IP経由）で`arxiv <キーワード>`を検索し、ヒットしたarxiv.orgのabstractページをweb_fetchで読む。この場合、出力に「arXiv API不達のためWeb検索フォールバックを使用した。網羅性・再現性はAPI検索より劣る」と明記し、検索式ベースの網羅的検索でない旨を限界として述べる。
3. 書誌情報は取得したabstractページの記載のみから転記し、記憶で補わない。

## 基本コマンド

以下の`SCRIPT`は、実行前に絶対パスへ解決したCLIを表す。

    python3 SCRIPT count 'large language models medical imaging'
    python3 SCRIPT search 'large language models medical imaging' --retmax 30 --sort-by relevance --output-mode compact
    python3 SCRIPT search 'retrieval augmented generation' --match phrase --category cs.AI --retmax 20
    python3 SCRIPT search '(ti:"large language model" OR abs:"large language model") AND cat:cs.AI' --raw --submitted-from 2025-01-01 --sort-by submittedDate --sort-order descending
    python3 SCRIPT search 'quantum error correction' --start 30 --retmax 30 --sort-by relevance
    python3 SCRIPT fetch 1706.03762 2005.14165v4

平文キーワードは既定で各語を`AND`結合して`all:`検索する。いずれかの語なら`--match any`、完全一致なら`--match phrase`を使う。arXiv固有の論理式は`--raw`で渡す。

## 検索式の原則

- 探索的検索では`all:`を使ってよい。ノイズを抑える検索では`ti:`と`abs:`をORで束ねる。
- 同義語はOR、異なる概念はAND、除外はANDNOTで結び、優先順位は丸括弧で明示する。
- 著者名は`au:`、主題分類は`cat:`を使う。複数の`--category`はOR、複数の`--author`はANDになる。
- 日付指定は初回投稿日に対するUTCの`submittedDate`であり、更新日フィルタではない。
- 検索結果の上限や分割規則を守る。1回は最大2,000件、先頭30,000件までとし、大量なら検索式を狭める。
- arXiv IDでの取得には`id_list`相当の`fetch`を使い、`id:`検索で代用しない。

## 精度と安全

- arXiv収載は査読済みであることを意味しない。preprintである点、版、初回投稿日、更新日を必要に応じて明示する。
- abstractにない方法・数値・結論は記載なしとする。本文が必要ならabstractページまたはPDFへリンクし、著作権とライセンスを尊重する。
- 検索順位や新しさを研究の質の指標として扱わない。
- APIエラー、通信失敗、0件を文献なしの確証へすり替えない。
- arXiv（Fastly）はIP単位でrate limitする。共有IP環境ではHTTP 429が出やすい。CLIは429時に20〜90秒の長いバックオフとRetry-After（最大300秒）を適用し、クールダウンをrate-stateファイル経由で全プロセスと共有する。429が続く場合は、検索式を変えて連射せず、1〜2分待ってから同じ検索式で再実行する。並列でCLIを起動しない。
