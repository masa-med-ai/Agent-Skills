# J-STAGE WebAPI and abstract retrieval

Verified against official pages on 2026-08-16.

## Official sources

- WebAPI overview: https://www.jstage.jst.go.jp/static/pages/JstageServices/TAB3/-char/ja
- WebAPI terms: https://www.jstage.jst.go.jp/static/pages/WebAPI/-char/ja
- WebAPI manual Ver.2.0 (2026-03-26): https://www.jstage.jst.go.jp/static/files/ja/manual_api.pdf
- J-STAGE FAQ: https://www.jstage.jst.go.jp/static/pages/FAQs/TAB3/-char/ja
- Browsing terms: https://www.jstage.jst.go.jp/static/pages/TermsAndPolicies/ForIndividuals/-char/ja
- CiNii Research OpenSearch comparison: https://support.nii.ac.jp/ja/cir/r_opensearch

## Article search

Endpoint:

```text
https://api.jstage.jst.go.jp/searchapi/do?service=3&...
```

Search parameters:

| Parameter | Field | Match |
| --- | --- | --- |
| `material` | Journal/publication title | Contains |
| `article` | Article title | Contains |
| `author` | Author | Contains |
| `affil` | Affiliation | Contains |
| `keyword` | Author keywords | Contains |
| `abst` | Abstract | Contains |
| `text` | Full text | Contains |
| `issn` | Print or online ISSN | Exact `XXXX-XXXX` |
| `cdjournal` | J-STAGE journal code | Exact |
| `vol`, `no` | Volume, issue | Exact |
| `pubyearfrom`, `pubyearto` | Publication year range | Four-digit year |
| `sortflg` | `1` relevance; `2` bibliographic order | Default `1` |
| `start`, `count` | Page start and size | API manual maximum `count=1000` |

Separate words in one parameter with ASCII spaces for AND. Different populated parameters constrain the same request. No OR grammar is documented; issue separate queries and union them. `sortflg=2` requires `material` or `issn`.

The XML is Atom/OpenSearch with PRISM metadata. Article entries expose bilingual titles, article-page URLs, bilingual authors, journal titles, print/electronic ISSN, volume, issue, pages, year, DOI/JOI when available, and publication/update date. The WebAPI response schema does not expose abstract text.

Important statuses:

- `0`: success.
- `WARN_002`: matches exceed the API result ceiling; returned entries remain usable.
- `ERR_001`: zero results.
- `ERR_003`: concurrency limit; retry with backoff.
- `ERR_004`–`ERR_014`: invalid or incomplete request; correct the query rather than fabricating results.

## Abstract retrieval

Use the API's `article_link` after metadata search. Current J-STAGE article pages expose the displayed abstract in a language-specific HTML meta element:

```html
<meta name="abstract" content="...">
```

This page structure is observed behavior, not a documented WebAPI response contract. Treat a missing meta element as “not found on the checked page.” Keep retrieval sequential, rate-limited, and limited to a small user-selected set.

## Terms guardrails

- API use constitutes agreement to the J-STAGE WebAPI terms.
- Noncommercial use does not require an application; commercial use requires prior JST approval even when the service offered is free.
- Display `Powered by J-STAGE` with a J-STAGE link when showing API-derived information.
- Do not keep API-provided information machine-readable on a server or cloud for 24 hours or longer.
- Do not mechanically download large volumes of API information or J-STAGE content.
- Article copyrights normally belong to publishers/authors. Do not build a reusable abstract database or republish abstracts beyond legally permitted use or the article's explicit license.
- Treat full abstract text as transient screening input. In user-facing output, paraphrase and link rather than reproducing the full abstract; keep any necessary direct quotation to no more than 25 words from an article.

The bundled script therefore caps API pages at 100 records per call, caps article-page enrichment at 20 records, enforces a one-second minimum delay, and does not write a cache.

## CiNii Research comparison

CiNii Research OpenSearch v2 is free after developer registration and requires `appid`. Its responses may contain deposited abstracts and an `abstractLicenseFlag`, but its dedicated `description` search parameter does not apply to the `articles` search type. Use it to broaden coverage, not as a drop-in replacement for J-STAGE's `abst` field search.
