---
name: search-japanese-literature
description: Search Japanese scholarly literature in J-STAGE at no API cost, including field-specific searches of abstract text, titles, authors, affiliations, keywords, and full text; retrieve normalized bibliographic metadata and, for a small user-directed result set, enrich records with public Japanese or English abstracts from J-STAGE article pages. Use when the user asks for Japanese-language papers, J-STAGE searches, Japanese abstract searches, 和文論文, 国内文献, 抄録検索, or a PubMed-like search focused on Japanese literature. Do not use it as the sole database for an exhaustive international systematic review.
---

# Search Japanese Literature

Use J-STAGE WebAPI article search (`service=3`) as the no-key primary source. Run the bundled script for deterministic request construction, XML parsing, and limited abstract enrichment.

## Search workflow

1. Translate the request into explicit search fields. Use `--abstract` when the user asks for words occurring in abstracts. Use `--article`, `--author`, `--affiliation`, `--keyword`, or `--fulltext` only when that field is intended.
2. Preserve the user's Japanese terms. Add English synonyms as separate searches when useful; J-STAGE does not document OR syntax, and space-separated terms within one parameter are ANDed.
3. Run `scripts/jstage_search.py`. Start with 20 or fewer metadata results. Fetch article-page abstracts only for the most relevant records and never more than 20 records per request.
4. If several searches are needed, merge results by DOI, then by canonical J-STAGE article URL. Keep the best available Japanese title and authors.
5. Report the exact fielded queries, retrieval date, total hits, number returned, and number whose abstracts were obtained. Link every included record to its J-STAGE article page or DOI.
6. Label conclusions based only on abstracts as abstract-level evidence. Do not infer peer-review status, study design, or full-text findings when those facts are not explicit.
7. Use retrieved abstract text transiently for screening and paraphrased summaries. Do not paste complete abstracts into the user-facing answer. Keep any direct quotation brief (no more than 25 words from one article) and link to the article page.

## Run the script

Resolve the skill directory from the loaded `SKILL.md`, then run:

```bash
python3 <skill-dir>/scripts/jstage_search.py \
  --abstract "大腸内視鏡 人工知能" \
  --from-year 2020 \
  --count 20 \
  --fetch-abstracts \
  --abstract-limit 10 \
  --abstract-languages ja \
  --format json
```

Useful mappings:

- Abstract text: `--abstract`
- Article title: `--article`
- Author / affiliation: `--author`, `--affiliation`
- Author keywords: `--keyword`
- Full text: `--fulltext`
- Journal / ISSN / journal code: `--journal`, `--issn`, `--journal-code`
- Publication window: `--from-year`, `--to-year`
- Pagination: `--start`, `--count`
- Human-readable preview: `--format markdown`

Multiple populated fields are combined by the API as constraints. For title-or-abstract retrieval, run one `--article` search and one `--abstract` search, then deduplicate; do not pass both unless the user wants both fields to match.

## Abstract enrichment rules

- Prefer the J-STAGE article page returned by the API. The script reads the page's `<meta name="abstract">`; absence is a valid outcome.
- Use Japanese abstracts by default. Request `--abstract-languages ja,en` only when bilingual abstracts add value because this doubles page requests.
- Keep the built-in delay of at least one second between article-page requests. Do not parallelize page retrieval or bypass the 20-record cap.
- Never claim an abstract was unavailable merely because one language page lacked it; state which language page was checked.
- Do not silently substitute snippets, full text, or model-generated text for a missing abstract.
- Use JSON output for internal analysis. The Markdown formatter intentionally reports abstract availability without reproducing the full text.

## Terms and output requirements

For routine, noncommercial, user-directed scholarly searching, proceed with modest result counts. Always include `Powered by [J-STAGE](https://www.jstage.jst.go.jp/browse/-char/ja)` in a user-facing result.

Before commercial use, bulk harvesting, persistent machine-readable storage, or database creation, read [references/jstage-api.md](references/jstage-api.md) and stop if the requested use conflicts with the terms. J-STAGE requires prior approval for commercial API use, prohibits mechanical bulk downloading, and limits machine-readable API caching to less than 24 hours. Do not persist raw API results by default.

## Search quality

- For sensitivity, run Japanese spelling variants, abbreviations, and English terms as separate queries and present them as a reproducible search log.
- For precision, combine abstract terms with year, journal, author, or ISSN constraints.
- Treat `WARN_002` as a truncated-result warning, not a failed search. Refine the query or paginate only within the user's requested scope.
- For an exhaustive review, supplement J-STAGE with PubMed and appropriate Japanese databases. CiNii Research is a useful free-registration complement but requires an application ID and does not provide a dedicated abstract-field parameter for article searches.

Consult [references/jstage-api.md](references/jstage-api.md) for parameter semantics, response fields, error handling, and official source links.
