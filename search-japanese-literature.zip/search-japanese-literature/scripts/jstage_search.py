#!/usr/bin/env python3
"""Search J-STAGE article metadata and optionally retrieve a few abstracts.

Uses only the Python standard library. JSON is the default output so an agent can
deduplicate and synthesize results without reparsing XML or HTML.
"""

from __future__ import annotations

import argparse
import html
from html.parser import HTMLParser
import json
import re
import sys
import time
from datetime import datetime, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET


API_URL = "https://api.jstage.jst.go.jp/searchapi/do"
JSTAGE_HOME = "https://www.jstage.jst.go.jp/browse/-char/ja"
TERMS_URL = "https://www.jstage.jst.go.jp/static/pages/WebAPI/-char/ja"
USER_AGENT = "search-japanese-literature/1.0 (+J-STAGE scholarly search)"
NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "prism": "http://prismstandard.org/namespaces/basic/2.0/",
    "opensearch": "http://a9.com/-/spec/opensearch/1.1/",
}
SEARCH_FIELDS = (
    "material",
    "article",
    "author",
    "affil",
    "keyword",
    "abst",
    "text",
    "issn",
    "cdjournal",
    "vol",
    "no",
)


class JStageError(RuntimeError):
    """Raised for network, parse, or API errors."""


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


class _AbstractMetaParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.abstract: str | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "meta" or self.abstract is not None:
            return
        values = {key.lower(): value for key, value in attrs if value is not None}
        if values.get("name", "").lower() == "abstract" and values.get("content"):
            self.abstract = clean_text(values["content"])


def clean_text(value: str | None) -> str | None:
    if value is None:
        return None
    parser = _TextExtractor()
    try:
        parser.feed(value)
        parsed = "".join(parser.parts)
    except Exception:
        parsed = value
    parsed = html.unescape(parsed)
    parsed = re.sub(r"\s+", " ", parsed).strip()
    return parsed or None


def _text(element: ET.Element | None, path: str) -> str | None:
    if element is None:
        return None
    child = element.find(path, NS)
    return clean_text(child.text if child is not None else None)


def _int_text(element: ET.Element, path: str, default: int = 0) -> int:
    value = _text(element, path)
    try:
        return int(value) if value is not None else default
    except ValueError:
        return default


def _request_bytes(url: str, timeout: float, retries: int = 3) -> bytes:
    retryable = {429, 500, 502, 503, 504}
    last_error: Exception | None = None
    for attempt in range(retries):
        request = Request(
            url,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/xml,text/html;q=0.9,*/*;q=0.1",
            },
        )
        try:
            with urlopen(request, timeout=timeout) as response:
                return response.read()
        except HTTPError as exc:
            last_error = exc
            if exc.code not in retryable or attempt + 1 >= retries:
                break
            retry_after = exc.headers.get("Retry-After")
            try:
                delay = max(float(retry_after), 1.0) if retry_after else 2.0**attempt
            except ValueError:
                delay = 2.0**attempt
            time.sleep(delay)
        except (URLError, TimeoutError, OSError) as exc:
            last_error = exc
            if attempt + 1 >= retries:
                break
            time.sleep(2.0**attempt)
    raise JStageError(f"request failed for {url}: {last_error}")


def _multilingual(entry: ET.Element, tag: str) -> dict[str, str | None]:
    parent = entry.find(f"atom:{tag}", NS)
    return {"ja": _text(parent, "atom:ja"), "en": _text(parent, "atom:en")}


def _authors(entry: ET.Element) -> dict[str, list[str]]:
    parent = entry.find("atom:author", NS)
    result: dict[str, list[str]] = {"ja": [], "en": []}
    if parent is None:
        return result
    for language in ("ja", "en"):
        container = parent.find(f"atom:{language}", NS)
        if container is None:
            continue
        result[language] = [
            value
            for node in container.findall("atom:name", NS)
            if (value := clean_text(node.text)) is not None
        ]
    return result


def _article_urls(entry: ET.Element) -> dict[str, str | None]:
    urls = _multilingual(entry, "article_link")
    if not urls["ja"]:
        link = entry.find("atom:link", NS)
        urls["ja"] = clean_text(link.get("href")) if link is not None else None
    return urls


def _parse_entry(entry: ET.Element) -> dict[str, Any]:
    first_page = _text(entry, "prism:startingPage")
    last_page = _text(entry, "prism:endingPage")
    if first_page and last_page and first_page != last_page:
        pages = f"{first_page}-{last_page}"
    else:
        pages = first_page or last_page
    doi = _text(entry, "prism:doi")
    return {
        "source": "J-STAGE",
        "title": _multilingual(entry, "article_title"),
        "authors": _authors(entry),
        "journal": _multilingual(entry, "material_title"),
        "journal_code": _text(entry, "atom:cdjournal"),
        "issn": {
            "print": _text(entry, "prism:issn"),
            "electronic": _text(entry, "prism:eIssn"),
        },
        "volume": _text(entry, "prism:volume"),
        "issue": _text(entry, "prism:number"),
        "pages": pages,
        "year": _text(entry, "atom:pubyear"),
        "joi": _text(entry, "atom:joi"),
        "doi": doi,
        "doi_url": f"https://doi.org/{doi}" if doi else None,
        "article_url": _article_urls(entry),
        "published_at": _text(entry, "atom:updated"),
        "abstract": {"ja": None, "en": None},
        "abstract_source_url": {"ja": None, "en": None},
        "abstract_status": {"ja": "not_requested", "en": "not_requested"},
    }


def parse_search_xml(data: bytes) -> dict[str, Any]:
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise JStageError(f"invalid XML response: {exc}") from exc
    status = _text(root, "atom:result/atom:status") or ""
    message = _text(root, "atom:result/atom:message")
    entries = [] if status == "ERR_001" else root.findall("atom:entry", NS)
    result = {
        "status": status,
        "message": message,
        "api_updated": _text(root, "atom:updated"),
        "total_results": _int_text(root, "opensearch:totalResults"),
        "start_index": _int_text(root, "opensearch:startIndex", 1),
        "items_per_page": _int_text(root, "opensearch:itemsPerPage"),
        "records": [_parse_entry(entry) for entry in entries],
    }
    if status.startswith("ERR_") and status != "ERR_001":
        raise JStageError(f"J-STAGE API returned {status}: {message or status}")
    if status.startswith("SYS_ERR"):
        raise JStageError(f"J-STAGE API returned {status}: {message or status}")
    return result


def _language_url(record: dict[str, Any], language: str) -> str | None:
    urls = record["article_url"]
    base = urls.get(language) or urls.get("ja") or urls.get("en")
    if not base:
        return None
    base = re.sub(r"/-char/(?:ja|en)/?$", "", base.rstrip("/"), flags=re.IGNORECASE)
    if base.endswith("_article"):
        return f"{base}/-char/{language}/"
    return base


def _extract_abstract(page: bytes) -> str | None:
    parser = _AbstractMetaParser()
    parser.feed(page.decode("utf-8", errors="replace"))
    return parser.abstract


def enrich_abstracts(
    records: list[dict[str, Any]],
    languages: list[str],
    limit: int,
    delay: float,
    timeout: float,
) -> None:
    last_request_at: float | None = None
    for index, record in enumerate(records):
        for language in ("ja", "en"):
            if language not in languages:
                record["abstract_status"][language] = "language_not_requested"
        if index >= limit:
            for language in languages:
                record["abstract_status"][language] = "record_limit_not_requested"
            continue
        for language in languages:
            url = _language_url(record, language)
            if not url:
                record["abstract_status"][language] = "no_article_url"
                continue
            if last_request_at is not None:
                remaining = delay - (time.monotonic() - last_request_at)
                if remaining > 0:
                    time.sleep(remaining)
            try:
                page = _request_bytes(url, timeout=timeout)
                last_request_at = time.monotonic()
                abstract = _extract_abstract(page)
                record["abstract_source_url"][language] = url
                if abstract:
                    record["abstract"][language] = abstract
                    record["abstract_status"][language] = "found"
                else:
                    record["abstract_status"][language] = "not_found_on_page"
            except JStageError as exc:
                last_request_at = time.monotonic()
                record["abstract_source_url"][language] = url
                record["abstract_status"][language] = f"fetch_error: {exc}"


def build_query(args: argparse.Namespace) -> dict[str, str]:
    query: dict[str, str] = {"service": "3"}
    mapping = {
        "from_year": "pubyearfrom",
        "to_year": "pubyearto",
        "journal": "material",
        "article": "article",
        "author": "author",
        "affiliation": "affil",
        "keyword": "keyword",
        "abstract": "abst",
        "fulltext": "text",
        "issn": "issn",
        "journal_code": "cdjournal",
        "volume": "vol",
        "issue": "no",
    }
    for argument, parameter in mapping.items():
        value = getattr(args, argument)
        if value is not None and str(value).strip():
            query[parameter] = str(value).strip()
    query["sortflg"] = "1" if args.sort == "relevance" else "2"
    query["start"] = str(args.start)
    query["count"] = str(args.count)
    return query


def _validate_args(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    query = build_query(args)
    if not any(field in query for field in SEARCH_FIELDS):
        parser.error("provide at least one article search field")
    if args.from_year and not re.fullmatch(r"\d{4}", args.from_year):
        parser.error("--from-year must be four digits")
    if args.to_year and not re.fullmatch(r"\d{4}", args.to_year):
        parser.error("--to-year must be four digits")
    if args.from_year and args.to_year and int(args.from_year) > int(args.to_year):
        parser.error("--from-year cannot exceed --to-year")
    if args.issn and not re.fullmatch(r"\d{4}-[\dXx]{4}", args.issn):
        parser.error("--issn must use XXXX-XXXX format")
    if args.sort == "bibliographic" and not (args.journal or args.issn):
        parser.error("bibliographic sorting requires --journal or --issn")
    if not 1 <= args.count <= 100:
        parser.error("--count must be between 1 and 100")
    if args.start < 1:
        parser.error("--start must be at least 1")
    if not 1 <= args.abstract_limit <= 20:
        parser.error("--abstract-limit must be between 1 and 20")
    if args.delay < 1.0:
        parser.error("--delay must be at least 1.0 seconds")
    languages = args.abstract_languages.split(",")
    if not languages or any(language not in {"ja", "en"} for language in languages):
        parser.error("--abstract-languages must be ja, en, ja,en, or en,ja")
    if len(set(languages)) != len(languages):
        parser.error("--abstract-languages cannot repeat a language")


def _markdown(document: dict[str, Any]) -> str:
    lines = [
        "# J-STAGE search results",
        "",
        f"- Retrieved: {document['retrieved_at']}",
        f"- Total hits: {document['total_results']}",
        f"- Returned: {len(document['records'])}",
        f"- API status: {document['api_status'] or '0'}",
        "",
    ]
    for number, record in enumerate(document["records"], 1):
        title = record["title"].get("ja") or record["title"].get("en") or "(untitled)"
        url = (
            record["article_url"].get("ja")
            or record["article_url"].get("en")
            or record.get("doi_url")
        )
        lines.append(f"## {number}. [{title}]({url})" if url else f"## {number}. {title}")
        authors = record["authors"].get("ja") or record["authors"].get("en")
        journal = record["journal"].get("ja") or record["journal"].get("en")
        citation = "; ".join(
            value
            for value in [
                ", ".join(authors) if authors else None,
                journal,
                record.get("year"),
                f"{record.get('volume')}({record.get('issue')})"
                if record.get("volume") and record.get("issue")
                else record.get("volume"),
                record.get("pages"),
            ]
            if value
        )
        if citation:
            lines.append(citation)
        if record.get("doi_url"):
            lines.append(f"DOI: [{record['doi']}]({record['doi_url']})")
        for language in ("ja", "en"):
            abstract = record["abstract"].get(language)
            if abstract:
                lines.extend(
                    [
                        "",
                        f"**Abstract ({language})**: retrieved ({len(abstract)} characters; "
                        "full text omitted from Markdown output)",
                    ]
                )
        missing = [
            f"{language}: {status}"
            for language, status in record["abstract_status"].items()
            if status not in {"found", "language_not_requested", "not_requested"}
        ]
        if missing:
            lines.extend(["", "Abstract status: " + "; ".join(missing)])
        lines.append("")
    lines.append(f"Powered by [J-STAGE]({JSTAGE_HOME})")
    return "\n".join(lines).rstrip() + "\n"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Search J-STAGE article metadata and optionally fetch a few public abstracts."
    )
    parser.add_argument("--abstract", help="terms that must occur in the abstract (API: abst)")
    parser.add_argument("--article", help="terms that must occur in the article title")
    parser.add_argument("--author", help="author name terms")
    parser.add_argument("--affiliation", help="author affiliation terms")
    parser.add_argument("--keyword", help="author keyword terms")
    parser.add_argument("--fulltext", help="terms that must occur in full text")
    parser.add_argument("--journal", help="journal/publication title terms")
    parser.add_argument("--issn", help="print or electronic ISSN in XXXX-XXXX format")
    parser.add_argument("--journal-code", help="J-STAGE cdjournal code")
    parser.add_argument("--volume", help="exact volume")
    parser.add_argument("--issue", help="exact issue")
    parser.add_argument("--from-year", help="publication year lower bound (YYYY)")
    parser.add_argument("--to-year", help="publication year upper bound (YYYY)")
    parser.add_argument("--sort", choices=("relevance", "bibliographic"), default="relevance")
    parser.add_argument("--start", type=int, default=1, help="one-based result offset")
    parser.add_argument("--count", type=int, default=20, help="metadata results, 1-100")
    parser.add_argument("--fetch-abstracts", action="store_true")
    parser.add_argument("--abstract-limit", type=int, default=10, help="records to enrich, 1-20")
    parser.add_argument(
        "--abstract-languages",
        default="ja",
        help="comma-separated page languages: ja, en, ja,en, or en,ja",
    )
    parser.add_argument("--delay", type=float, default=1.0, help="minimum seconds between pages")
    parser.add_argument("--timeout", type=float, default=30.0, help="HTTP timeout seconds")
    parser.add_argument("--format", choices=("json", "markdown"), default="json")
    parser.add_argument("--version", action="version", version="%(prog)s 1.0.0")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    _validate_args(args, parser)
    query = build_query(args)
    api_url = f"{API_URL}?{urlencode(query)}"
    try:
        parsed = parse_search_xml(_request_bytes(api_url, timeout=args.timeout))
        records = parsed["records"]
        languages = args.abstract_languages.split(",")
        if args.fetch_abstracts and records:
            enrich_abstracts(
                records,
                languages=languages,
                limit=args.abstract_limit,
                delay=args.delay,
                timeout=args.timeout,
            )
        retrieved_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        document = {
            "source": "J-STAGE",
            "source_credit": "Powered by J-STAGE",
            "source_url": JSTAGE_HOME,
            "terms_url": TERMS_URL,
            "abstract_text_notice": (
                "Transient screening input: paraphrase in user-facing output; do not reproduce "
                "complete abstracts, and limit direct quotation from one article to 25 words."
            ),
            "retrieved_at": retrieved_at,
            "query": query,
            "api_url": api_url,
            "api_status": parsed["status"],
            "api_message": parsed["message"],
            "api_updated": parsed["api_updated"],
            "total_results": parsed["total_results"],
            "start_index": parsed["start_index"],
            "items_per_page": parsed["items_per_page"],
            "records": records,
        }
        if args.format == "markdown":
            sys.stdout.write(_markdown(document))
        else:
            json.dump(document, sys.stdout, ensure_ascii=False, indent=2)
            sys.stdout.write("\n")
        return 0
    except JStageError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
